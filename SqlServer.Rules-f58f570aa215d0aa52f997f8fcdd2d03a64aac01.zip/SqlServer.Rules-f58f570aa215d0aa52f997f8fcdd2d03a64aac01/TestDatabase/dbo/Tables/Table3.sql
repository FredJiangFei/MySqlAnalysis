﻿CREATE TABLE [dbo].[Table3]
(
	[Id] INT NOT NULL, 
    [Wang] NCHAR(500) NOT NULL, 
    [Chung] NCHAR(10) NOT NULL 
)
