﻿CREATE TABLE [dbo].[Table6]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [FirstName] VARCHAR(50) NOT NULL, 
    [LastName] VARCHAR(50) NOT NULL, 
    [CreatedDate] DATETIME NOT NULL, 
    [ModifiedDate] DATETIME2 NULL
)
