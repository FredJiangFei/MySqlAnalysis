﻿namespace SqlServer.Dac.Visitors
{
	public enum ObjectTypeFilter
	{
		All,
		PermanentOnly,
		TempOnly
	}
}