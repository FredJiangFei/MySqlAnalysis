﻿namespace SqlServer.Dac.Visitors
{
	public interface IBaseVisitor
	{
		int Count { get; }
	}
}
