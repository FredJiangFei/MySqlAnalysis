﻿using System;
using Microsoft.SqlServer.TransactSql.ScriptDom;

namespace TSQLParser
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
