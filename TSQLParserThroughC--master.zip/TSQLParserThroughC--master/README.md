# TSQLParserThroughC#
1.  Microsoft.SqlServer.TransactSql.ScriptDom By Microsoft

              Works fine with select statement, need to test more options for update statement and other DDL and DML statements.

             https://gist.github.com/philippwiddra/2ee47ac4f8a0248c3a0e.
             http://www.andriescu.nl/sql/sql-how-to-parse-microsoft-transact-sql-statements-in-c_sharp_view_column_binding/


2.  tsql-parser   By Bruce Dunwiddie 

              This is for parsing only select statement. 

             https://github.com/bruce-dunwiddie/tsql-parser
